jquery-simple-datetimepicker (jquery.simple-dtpicker.js)
========

Date and time picker, simply. (jquery plugin)

![screenshot](https://raw.github.com/mugifly/jquery-simple-datetimepicker/master/design/dtpicker_mock.png)

Details and samples: http://mugifly.github.com/jquery-simple-datetimepicker

Your feedback is highly appreciated.
you can send requests and bug reports as [Issues on GitHub](https://github.com/mugifly/jquery-simple-datetimepicker/issues).

## Requirements

* jQuery 1.7.2 or later

## Contributors
Thank you to:

* [LeandroSe](https://github.com/LeandroSe)
* [dsims](https://github.com/dsims)
* [jjsgro](https://github.com/jjsgro)
* [mackeian](https://github.com/mackeian)
* [rdolgushin](https://github.com/rdolgushin)
* [Mauricio](http://www.mauricioprof.com/)
* [AndAniCalik](https://twitter.com/AndAniCalik)

## License and author

Copyright (c) 2013 Masanori Ohgita (http://ohgita.info/). 

This program is free software distributed under the terms of the MIT license. 
See LICENSE.txt for details.

